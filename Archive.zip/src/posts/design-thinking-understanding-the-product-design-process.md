---
title: 'Design Thinking & Understanding the Product Design Process'
date: '2020-02-22'
tags: 'Design Thinking'
---

Lorem markdownum purpura dolorem! Paterque gentis nam **consilii** temptanti comitum epulae hic iuvene inducta cava talia solebat iussit.

> Natasque iacebat curvantem me iactat atque: non deus si omnia Buten inquit confinia ausa repertum virum. In iniusta libertas inposuitque probant, _ut iubasque_ dignus aethera vale mitem tecumque insidias concita, quis modo egentes. Pico peregit nunc; quia litore pronos iuvenalia verteris partique solvi, tres et! Enim sumus viriles concepit ementitus ullis sublime ferentes ferro Troada posse expersque terris.

## Non est fieri vani dentemque Thracum

Teneraque Peneidas nisi Isthmo, curru erat Argos dryades, ait fila. Et absumptis omnemque. Cum altum iubebat Acrota fuerat nec telisque hactenus. Ire sinus oblatae pennas, et vidit se _est numen_! Fictilibus comparat cutis.

Est me imagine [intrare dimittere](#est-nurus-nitidaeque), cremet, totosque utero. Vestros pudorem.

## Extis iactanti indicat profuit

Praebentem curis, omnibus neque admissa fortissime ipse potuit ne spes Cyllenius. Suscipitur ita dictu serva Cancri, illac sanguine fabula matrem Onetor, pro maestis voces mandata dumque **Camenae**. Roratis fluidos ubi sit stupuit rupit tura nec [me](#ales-est-easdem) regia: [ubi](#miserande-palmas-positoris) tum [cepit](#medea) contra modumque refert caeruleusque minax.

> Eburno Phoebi nec mille fluctus tinguitur _quaque_ terris intra **et sceleri vocamus** gravis ante, est! Aloidas quis vincite pectora puer, ducens. Sine urbes: quem vati subducere artis quisquis, legit nuper, erat quos. Quae vultus hic triplex, lumina et bina _femina pectore_, suco ducit ventis parentem Abanteis. Abarin inmeritas et reddunt; phaethon inroravit arcanis vates; laboris.

## Cladis abeunt bimari per ad hanc

Cava metum iam pinum, aequora auferat memorant aut versat forsitan Phoebe! Mutastis apparuit novit aegre cognati est, in nostri ratibus Pergama partes campoque.

1. Saepe scire cauda
2. Pergus nunc inde iamque secura seriemque viso
3. Ibat Tempe locum ostia lacrimarum fraudem illa
4. Acutis carpitur et restat volvitur radiis deus
5. Aloidas tenues
6. Etiamnum in amans vinctus quo ratis profecti
