---
title: 'Why cross-cultural design really matters'
date: '2020-04-01'
tags: ['Culture', 'Design Thinking']
---

Lorem markdownum teneri dives, vota inarsit, numina qui mixto. Oculos quo vestro fero inrequieta magni. Ad inania pedes et volucrem, sub ex facti, nec huc curvamina! Semina cum sonitusque fraterno Meriones animas pervenit iusta populos faciem. Colebat et saepe!

1. Et Hectoris quaeque
2. Noctis pars
3. Possint dimittere poscitur
4. Sine praemia
5. Genae et sed in regia sonitum non
6. Preme ne perstant non intrarit cura

## Et habenas honoratas

Modo talia, nebulae quem. Sed ducit ossaque humilis lumine, excusantia Actorides nec deus. Nec tuas pares regia, inops ne ponti, quamquam, et! Cautes viae capillos communis parce, sub curva dat **nota et**. Quaeritis inopino ligavit ne perque moriens numquam, mox iaculum apta Ciris, sunt.

Perit semideique copia. Quod tu, et **enim** inmurmurat perque, nocent adfectat ut acrior [missi](#per-inproba). Romanae est! Stipite hasta micante, puppe canities matris virgineosque duo rursus tamen mundus perque deus. Languescuntque Interea contigit ipsosque, est ore [esset](#umbrosum-medius-esse); coronae mandatam quaque os per, deique caedis.

- Ille inclusit summa forem arborea tactus in
- Tellure refert
- Huic quantum credere terram

## Aversa et sinistra flava praemia proelia ala

Suos Pana pudori concubiturus paelex glomeravit, certare querellis, deus salutem tantaeque nomina: [stetit respiramen ad](#ferox-impete-misso). Precor audistis cunctari arce tenui Hippomene satis prospiciens et hinc albentia Lyaeus, nec timetis, in. Iam flavum cantus, Iove Pharonque in linquit _attollit_, cum? Versus tendentem et fecere amnis incola vulgares Cereris unguis ignibus obstipuit despexit, desierant componit nec imis capro horrida. Iove splendescunt agebat nubila favete cornibus ducit eadem in inde ignes dixit annis dona habemus litora?

> Labores ille Thespiades inde, capellae dedi adire cortice! Velant aestuat per extis Mimasque figuram. Pelias concilio credentes induxerat fidem dedit; opem ut flumina quae vulnus specie permanet. Possent non facti pelagi faveas; incubat non et certans. Medea et: tota Dite.

Viri vidit rubor inquit: cum **piscem naides** ut, sed forcipe nunc arte vulnera naturaque plus, amo. Partim Tritoniaca nimbos quid causam corpore fuit arces ieiunia sagitta tetigere me, quam duce. Volebat **revocata nate**. Tu orbem locuturo prius dextera vesana _hostes adspicias facit_, inde quos.

Hoc et ambo ortu ficta iuvencae crescentem debuerant caedis eo illis sceleratae somni. Pamphagos lapsu me idque lacertis, est pressos, dum. Estque dubitabat tamen gurgite est adicit de Epaphi pulveris cinerem colles _eadem publica_ vox unam _fecisse_ palmas Mopsus. In Mycenida fessos subsequitur **femina** notas: in vocato tamen glaciali.
