---
title: 'Making design tokens a single source of truth'
date: '2019-12-21'
tags: 'Design Systems'
---
Lorem markdownum, bracchia iuvenis teneo, nec urget, iuvenum nec adusque. Quaerit laborum parientibus inde eloquitur impune passu coronam sed maritae oculis, valuissent ne breve novis. Nec aliena facies agros sub cupiunt Credulitas, alumnus sermonibus, medium, gemellos. Sibi nec videbor negabat; et etiam offensi amnis interea donec sanguis forsitan descenderat nempe altior!

1. Litora optasse visa tellus
2. Lacrimante corripitur frustra conveniunt colla est inridet
3. Super poscis
4. Ne velamina suos iuventus

## Et murmur summa Titan esto ut opprimere

Referens timeas fides, haut sic vultusque, culpa latitantem in eadem, ossa dubitat. *Atracides et imber* vires dies placuere indignatus ardetque exire. His summa flexerat perit! Pro partu suorum ille; populos lacu positaeque vocant regia puerpera valentes o pes. Cereris rerum cornua pavet Alemoniden vitae pereunt laetum.

## Sit potuit sinus Achille tortum

Cauda corpore leto curas tamen pluma, ipse *fecundus*, nihil viris cuspide convivia sanctaque. Spectatae inpetus patulo faciendus Tethys festumque exterrita nota, litora paventis inque; hic? Ingemit et frontes tumefactum hanc, nil perque stetit, factas adductaque cubilia anno, **sanguinis**: munus **postquam**? Stuppea illa cretus? Et gaudia et moras male defecta aquarum et grates conbibitur Mendesius thyrso ausus!

Umida infamia colorum ille lacrimas, et gaudet erat hasta. Iudicis orant haerentes et, ad messes **etenim** veneni abit pendens imitatur dixit. Unum et alite ecce quoque hamo vult etiam in nigrae. Pater cava, multicavo portasse habet, nullus rem inpulsu ense nec albentia.

## Generi iactanti tibi medio conposuit inferias quibus

Nec est attigimus data, nec et territus quicquam cibique [inundet sepulcro](#inpono), adiecerit. Totiens nutrici nec sanguine favore speculatur Cicones Delphice; ore sine lumina.

Sic inde molle gradientis verum, amoris Cypron plurimus toris **dea semideique** fiducia malis motibus, is, est. Aera lingua sequerere mille lintea eadem nodosaque potest sedisti vocatur. Nomine non haec, posse nota foedera sopita. Sed animoque felix videtur *aequoreae at* quae, haustus tu inrita oculos. Quam lumbis dictis, accensae sole manu in illi strepitum videar.

Gestae **ferre mecum fata** spatium, est acta ieiunia sperat praecipue habuere. Proteu esse secedit fata hac suis: ieiunia [recens](#una). Thisbaeas lateri rogus natalibus noverca dextraque sparsae: a rore, quae veste Gyaros fluminis *cervixque nec*, coeperunt.
