---
title: 'About Issue 33'
layout: 'layouts/about.html'
permalink: '/about-us/index.html'
---

Wanna see our foosball table? Nah, only kidding. We’re a made-up
agency being used as an example for the Piccalilli course,
[Learn Eleventy From Scratch](https://learneleventyfromscratch.com).